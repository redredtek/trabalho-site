window.onload = function() {
  const totalImagens = 4;

  // Função para gerar número aleatório entre 1 e totalImagens
  function gerarImagemAleatoria() {
    return Math.floor(Math.random() * totalImagens) + 1;
  }

  // Gera imagens diferentes ou iguais aleatoriamente
  const imagem1 = gerarImagemAleatoria();
  const imagem2 = "2" + gerarImagemAleatoria();
  const imagem3 = "3" + gerarImagemAleatoria();
  const imagem4 = "4" + gerarImagemAleatoria();

  document.getElementById("imagem1").src = `masc imgs/${imagem1}.png`;
  document.getElementById("imagem2").src = `masc imgs/${imagem2}.png`;
  document.getElementById("imagem3").src = `fem imgs/${imagem3}.png`;
  document.getElementById("imagem4").src = `fem imgs/${imagem4}.png`;
};